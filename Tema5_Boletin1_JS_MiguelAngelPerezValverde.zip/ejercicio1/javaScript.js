// Este es el primer mensaje que se mostrará en la consola
console.log("Hola Mundo!");

// Este es el segundo mensaje que se mostrará en la consola
console.log("Soy el primer script");